﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using eSubmission.Data;
using eSubmission.Models;

namespace eSubmission.Pages.Contacts
{
    public class IndexModel : PageModel
    {
        private readonly eSubmission.Data.ApplicationDbContext _context;

        public IndexModel(eSubmission.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public string NameSort { get; set; }
        public string DateSort { get; set; }
        public string CurrentFilter { get; set; }
        public string CurrentSort { get; set; }

        public IList<Employee> Contact { get; set; }

        public async Task OnGetAsync(string sortOrder, string searchString)
        {
            NameSort = String.IsNullOrEmpty(sortOrder) ? "name_desc" : "";
            DateSort = sortOrder == "Date" ? "date_desc" : "Date";
            CurrentFilter = searchString;

            IQueryable<Employee> ContactId = from s in _context.Employee
                                             select s;

            if (!string.IsNullOrEmpty(searchString))
            {
                ContactId = ContactId.Where(s => s.FullName.Contains(searchString));
            }

            switch (sortOrder)
            {
                case "name_desc":
                    ContactId = ContactId.OrderByDescending(s => s.FullName);
                    break;
                case "Date":
                    ContactId = ContactId.OrderBy(s => s.Date);
                    break;
                case "date_desc":
                    ContactId = ContactId.OrderByDescending(s => s.Date);
                    break;
                default:
                    ContactId = ContactId.OrderBy(s => s.FullName);
                    break;
            }
            Contact = await ContactId.AsNoTracking().ToListAsync();
        }

    }
}
