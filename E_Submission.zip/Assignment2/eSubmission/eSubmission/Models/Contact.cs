﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using System.ComponentModel.DataAnnotations;

namespace eSubmission.Models
{
    public class Employee
    {
        // user ID from AspNetUser table.
        public string OwnerID { get; set; }

        public int EmployeeId { get; set; }

        [MinLength(5, ErrorMessage = "Minimum length of name should be 5 characters")]
        [Required(ErrorMessage = "Employee Name is required")]
        public string FullName { get; set; }

        [Required(ErrorMessage = "Department is required")]
        [MinLength(5, ErrorMessage = "Minimum length of department name should be 5 characters")]
        public string Department { get; set; }
        
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}",ApplyFormatInEditMode = true)]
        public DateTime Date { get; set; }

        [Required(ErrorMessage = "Description is required")]
        [MinLength(10, ErrorMessage = "Minimum length of description should be 10 characters")]
        public string Description { get; set; }


        [Required]
        [Range(0, 9999.99)]
        public double TotalClaimAmount { get; set; }

        [Required(ErrorMessage = "Address is required")]
        [MinLength(10, ErrorMessage = "Minimum length of address should be 20 characters")]
        public string Address { get; set; }

        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        public ContactStatus Status { get; set; }
    }
    public enum ContactStatus
    {
        Submitted,
        Approved,
        Rejected
    }
}
