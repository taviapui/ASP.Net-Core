﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Health_SelfDeclaration.Models;

namespace Health_SelfDeclaration.ViewModels
{
    public class AdminAddViewModel
    {
        public List<SelfDeclaration> Health_SelfDeclaration { get; set; }
        public SelfDeclaration NewEmployee { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
