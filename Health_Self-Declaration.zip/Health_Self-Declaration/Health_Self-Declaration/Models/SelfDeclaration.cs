﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Health_SelfDeclaration.Models
{
    public class SelfDeclaration
    {
        public int No { get; set; }
        public string EmployeeId { get; set; }
        public string FullName { get; set; }
        public string MobileNumber { get; set; }
        public string Address { get; set; }
        public string Position { get; set; }
        public string TravelRecord { get; set; }
        public string NoteTravelRecord { get; set; }
        public string HomeQuaratine { get; set; }
        public string ConfirmCase { get; set; }
        public string SicknessSymptoms { get; set; }
        public DateTime Date { get; set; }
    }
}

