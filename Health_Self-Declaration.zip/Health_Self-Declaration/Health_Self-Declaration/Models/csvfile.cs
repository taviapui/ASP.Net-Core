﻿using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Globalization;


namespace Health_SelfDeclaration.Models
{
    public class csvfile
    {
        string path = @"C:\Users\User\source\repos\Health_Self-Declaration\Record.txt";   //Change to your path!!!!!!!!!!!!!!!!!

        public csvfile()
        {
            if (!File.Exists(path))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(path))
                {

                }

            }

        }

        public void writeToCSV(String input)
        {

            using (StreamWriter sw = File.AppendText(path))
            {
                sw.Write(input);
            }

        }

        public List<SelfDeclaration> readFromCSV()
        {
            List<SelfDeclaration> totalList = new List<SelfDeclaration>();


            var builder = new StringBuilder();

            // Open the file to read from.
            using (StreamReader sr = File.OpenText(path))
            {

                CultureInfo provider = CultureInfo.InvariantCulture;

                string s = "";
                int i = 0;
                while ((s = sr.ReadLine()) != null)
                {
                    i = i + 1;
                    string[] data = s.Split(',');
                    SelfDeclaration emp1 = new SelfDeclaration
                    {
                        No = i,
                        EmployeeId = data[1],
                        FullName = data[2],
                        MobileNumber = data[3],
                        Address = data[4],
                        Position = data[5],
                        TravelRecord = data[6],
                        NoteTravelRecord = data[7],
                        HomeQuaratine = data[8],
                        ConfirmCase = data[9],
                        SicknessSymptoms = data[10],
                        Date = DateTime.Parse(data[11])
                    };
                    totalList.Add(emp1);

                }
            }
            return totalList;
        }
    }
}
