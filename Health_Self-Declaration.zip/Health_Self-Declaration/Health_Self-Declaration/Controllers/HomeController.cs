﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using System.Text;
using Health_SelfDeclaration.ViewModels;
using Health_SelfDeclaration.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Health_SelfDeclaration.Controllers
{
    public class HomeController : Controller
    {
       
        // GET: /<controller>/
        public IActionResult Index()
        {
            AdminAddViewModel AdminAddViewModel = new AdminAddViewModel();

            csvfile reader = new csvfile();
            AdminAddViewModel.Health_SelfDeclaration = reader.readFromCSV();

            AdminAddViewModel.NewEmployee = new SelfDeclaration();

            return View(AdminAddViewModel);
        }

        [Route("adminView")]
        public IActionResult admin()
        {
            AdminAddViewModel AdminAddViewModel = new AdminAddViewModel();

            csvfile reader = new csvfile();
            AdminAddViewModel.Health_SelfDeclaration = reader.readFromCSV();

            AdminAddViewModel.NewEmployee = new SelfDeclaration();

            return View(AdminAddViewModel);
        }

        [HttpPost]
        public IActionResult Index(AdminAddViewModel AdminAddViewModel)
        {
            string iDate = AdminAddViewModel.NewEmployee.Date.ToString("dd/MM/yyyy");
            

            var builder = new StringBuilder();
            builder.AppendLine($"{AdminAddViewModel.NewEmployee.No},{ AdminAddViewModel.NewEmployee.EmployeeId}," +
                $"{AdminAddViewModel.NewEmployee.FullName},{AdminAddViewModel.NewEmployee.MobileNumber}," +
                $"{AdminAddViewModel.NewEmployee.Address}," +
                $"{AdminAddViewModel.NewEmployee.Position},{AdminAddViewModel.NewEmployee.TravelRecord}," +
                $"{AdminAddViewModel.NewEmployee.NoteTravelRecord}, {AdminAddViewModel.NewEmployee.HomeQuaratine}," +
                $"{AdminAddViewModel.NewEmployee.ConfirmCase}, {AdminAddViewModel.NewEmployee.SicknessSymptoms},{iDate}");

            csvfile writer = new csvfile();
            writer.writeToCSV(builder.ToString());

            return RedirectToAction("linkToPage");
        }


        public IActionResult Password()
        {
            AdminAddViewModel AdminAddViewModel = new AdminAddViewModel();

            List<SelfDeclaration> totalList = new List<SelfDeclaration>();
            SelfDeclaration emp1 = new SelfDeclaration
            {
                
                FullName = "Please login to view the admin list",
                
            };
            totalList.Add(emp1);
            AdminAddViewModel.Health_SelfDeclaration = totalList;

            AdminAddViewModel.NewEmployee = new SelfDeclaration();



            return View(AdminAddViewModel);
        }



        [Route("login")]
        public IActionResult Password(AdminAddViewModel AdminAddViewModel)
        {
            bool passwordFlag = false;
            String mUserName = AdminAddViewModel.Username;
            String mPassword = AdminAddViewModel.Password;



            if ((string.Compare(mUserName, "admin") == 0) && (string.Compare(mPassword, "admin") == 0))
            {
                passwordFlag = true;
            }
            else
            {
                passwordFlag = false;
            }

            if (passwordFlag == true)
            {
                csvfile reader = new csvfile();
                AdminAddViewModel.Health_SelfDeclaration = reader.readFromCSV();
            }
            else
            {
                List<SelfDeclaration> totalList = new List<SelfDeclaration>();
                SelfDeclaration emp1 = new SelfDeclaration
                {
                    
                    FullName = "Please login to view the admin list",
                    
                };
                totalList.Add(emp1);
                AdminAddViewModel.Health_SelfDeclaration = totalList;
            }
            AdminAddViewModel.NewEmployee = new SelfDeclaration();



            return View(AdminAddViewModel);
        }

        [Route("Home/linkToPage")]
        public IActionResult backTo()
        {
            return View();
        }
    }
}
